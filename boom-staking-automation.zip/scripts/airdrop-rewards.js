require("dotenv").config();
const { ethers } = require("ethers");

const BOOM_TOKEN = "0xYourBoomTokenAddress";
const STAKING_CONTRACT = "0xYourStakingContractAddress";
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const RPC_URL = process.env.RPC_URL;

const provider = new ethers.providers.JsonRpcProvider(RPC_URL);
const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
const boomToken = new ethers.Contract(BOOM_TOKEN, ["function transfer(address,uint256) external"], wallet);
const stakingContract = new ethers.Contract(STAKING_CONTRACT, ["function totalStaked() view returns (uint256)", "function stakes(address) view returns (uint256, uint256)"], provider);

async function distributeRewards() {
    console.log("Fetching staking data...");

    const totalStaked = await stakingContract.totalStaked();
    if (totalStaked == 0) {
        console.log("No LP staked.");
        return;
    }

    const users = ["0xUser1", "0xUser2", "0xUser3"];
    const rewardPool = ethers.utils.parseEther("1000");

    for (const user of users) {
        const [stakedAmount] = await stakingContract.stakes(user);
        if (stakedAmount > 0) {
            const userShare = (stakedAmount * rewardPool) / totalStaked;
            await boomToken.transfer(user, userShare);
            console.log(`Airdropped ${ethers.utils.formatEther(userShare)} BOOM to ${user}`);
        }
    }
}

distributeRewards();
