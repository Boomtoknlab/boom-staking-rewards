# BOOM Staking & Airdrop Automation

This project includes a **staking smart contract** and an **automated airdrop script** to reward liquidity providers with BOOM tokens.

## 📌 Features
- Liquidity Mining Rewards (Auto-reward stakers every block)
- Automated BOOM Airdrops for Stakers
- Staking & Unstaking Support

## 🛠 Setup Instructions

1️⃣ **Install Dependencies**
```sh
npm install ethers dotenv axios
```

2️⃣ **Modify `.env` File**
```env
PRIVATE_KEY=your_wallet_private_key
RPC_URL=https://your_rpc_url
```

3️⃣ **Deploy Smart Contract**
Compile and deploy `BoomStaking.sol` on Etherscan or Remix.

4️⃣ **Run Airdrop Script**
```sh
node scripts/airdrop-rewards.js
```

🚀 **Enjoy automatic staking rewards and airdrops!**
